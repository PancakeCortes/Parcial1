package com.example.practica1Git;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica1GitApplicationTests {

	@Test
	void contextLoads() {
	}

}
