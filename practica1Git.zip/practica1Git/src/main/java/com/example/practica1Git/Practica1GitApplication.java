package com.example.practica1Git;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practica1GitApplication {

	public static void main(String[] args) {
		SpringApplication.run(Practica1GitApplication.class, args);
	}

}
